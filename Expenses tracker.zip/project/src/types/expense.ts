export interface Expense {
  id: string;
  amount: number;
  description: string;
  category: string;
  date: string;
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  color: string;
  icon: string;
}

export interface ExpenseStats {
  totalAmount: number;
  totalExpenses: number;
  averageExpense: number;
  categoryTotals: Record<string, number>;
  monthlyTotals: Record<string, number>;
}