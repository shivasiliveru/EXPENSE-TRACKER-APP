import { Category } from '../types/expense';

export const defaultCategories: Category[] = [
  { id: '1', name: 'Food & Dining', color: '#ef4444', icon: 'UtensilsCrossed' },
  { id: '2', name: 'Transportation', color: '#3b82f6', icon: 'Car' },
  { id: '3', name: 'Shopping', color: '#8b5cf6', icon: 'ShoppingBag' },
  { id: '4', name: 'Entertainment', color: '#06b6d4', icon: 'Music' },
  { id: '5', name: 'Bills & Utilities', color: '#eab308', icon: 'Receipt' },
  { id: '6', name: 'Healthcare', color: '#10b981', icon: 'Heart' },
  { id: '7', name: 'Travel', color: '#f97316', icon: 'Plane' },
  { id: '8', name: 'Education', color: '#6366f1', icon: 'GraduationCap' },
  { id: '9', name: 'Personal Care', color: '#ec4899', icon: 'Sparkles' },
  { id: '10', name: 'Other', color: '#6b7280', icon: 'MoreHorizontal' },
];