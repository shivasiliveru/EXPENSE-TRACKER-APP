import React from 'react';
import { TrendingUp, TrendingDown, DollarSign, Receipt, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { ExpenseStats } from '../types/expense';
import { formatCurrency } from '../utils/calculations';

interface DashboardProps {
  stats: ExpenseStats;
}

const Dashboard: React.FC<DashboardProps> = ({ stats }) => {
  const currentMonth = new Date().toLocaleString('default', { month: 'long', year: 'numeric' });
  const currentMonthSpending = stats.monthlyTotals[currentMonth] || 0;
  
  const previousMonth = new Date();
  previousMonth.setMonth(previousMonth.getMonth() - 1);
  const prevMonthKey = previousMonth.toLocaleString('default', { month: 'long', year: 'numeric' });
  const previousMonthSpending = stats.monthlyTotals[prevMonthKey] || 0;
  
  const monthlyChange = previousMonthSpending === 0 ? 0 : 
    ((currentMonthSpending - previousMonthSpending) / previousMonthSpending) * 100;

  const isIncreased = monthlyChange > 0;

  const cards = [
    {
      title: 'Total Expenses',
      value: formatCurrency(stats.totalAmount),
      icon: DollarSign,
      gradient: 'from-blue-500 to-blue-600',
      bgGradient: 'from-blue-50 to-blue-100',
      iconBg: 'bg-blue-500'
    },
    {
      title: 'Total Transactions',
      value: stats.totalExpenses.toString(),
      icon: Receipt,
      gradient: 'from-emerald-500 to-emerald-600',
      bgGradient: 'from-emerald-50 to-emerald-100',
      iconBg: 'bg-emerald-500'
    },
    {
      title: 'Average Expense',
      value: formatCurrency(stats.averageExpense),
      icon: TrendingUp,
      gradient: 'from-amber-500 to-amber-600',
      bgGradient: 'from-amber-50 to-amber-100',
      iconBg: 'bg-amber-500'
    },
    {
      title: 'This Month',
      value: formatCurrency(currentMonthSpending),
      icon: isIncreased ? ArrowUpRight : ArrowDownRight,
      gradient: isIncreased ? 'from-red-500 to-red-600' : 'from-green-500 to-green-600',
      bgGradient: isIncreased ? 'from-red-50 to-red-100' : 'from-green-50 to-green-100',
      iconBg: isIncreased ? 'bg-red-500' : 'bg-green-500',
      change: previousMonthSpending > 0 ? {
        value: Math.abs(monthlyChange).toFixed(1),
        isIncreased
      } : null
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {cards.map((card, index) => (
        <div key={index} className="group">
          <div className={`bg-gradient-to-br ${card.bgGradient} rounded-2xl p-6 shadow-lg border border-white/20 backdrop-blur-sm transition-all duration-300 hover:shadow-xl hover:scale-105`}>
            <div className="flex items-center justify-between mb-4">
              <div className={`${card.iconBg} p-3 rounded-xl shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                <card.icon className="w-6 h-6 text-white" />
              </div>
              {card.change && (
                <div className={`flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-semibold ${
                  card.change.isIncreased 
                    ? 'bg-red-100 text-red-700' 
                    : 'bg-green-100 text-green-700'
                }`}>
                  {card.change.isIncreased ? (
                    <TrendingUp className="w-3 h-3" />
                  ) : (
                    <TrendingDown className="w-3 h-3" />
                  )}
                  {card.change.value}%
                </div>
              )}
            </div>
            
            <div>
              <p className="text-sm font-medium text-gray-600 mb-1">
                {card.title}
              </p>
              <p className="text-2xl font-bold text-gray-900">
                {card.value}
              </p>
              {card.change && (
                <p className="text-xs text-gray-500 mt-1">
                  vs last month
                </p>
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default Dashboard;