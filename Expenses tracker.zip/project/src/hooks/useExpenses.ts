import { useState, useEffect } from 'react';
import { Expense, Category } from '../types/expense';
import { storage } from '../utils/storage';

export const useExpenses = () => {
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = () => {
      setExpenses(storage.getExpenses());
      setCategories(storage.getCategories());
      setLoading(false);
    };

    loadData();
  }, []);

  const addExpense = (expense: Expense) => {
    storage.addExpense(expense);
    setExpenses(storage.getExpenses());
  };

  const updateExpense = (expense: Expense) => {
    storage.updateExpense(expense);
    setExpenses(storage.getExpenses());
  };

  const deleteExpense = (id: string) => {
    storage.deleteExpense(id);
    setExpenses(storage.getExpenses());
  };

  const getCategoryById = (id: string) => {
    return categories.find(cat => cat.id === id);
  };

  const getCategoryByName = (name: string) => {
    return categories.find(cat => cat.name === name);
  };

  return {
    expenses,
    categories,
    loading,
    addExpense,
    updateExpense,
    deleteExpense,
    getCategoryById,
    getCategoryByName
  };
};