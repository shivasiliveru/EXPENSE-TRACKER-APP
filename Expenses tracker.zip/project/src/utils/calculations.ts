import { Expense, ExpenseStats } from '../types/expense';

export const calculateStats = (expenses: Expense[]): ExpenseStats => {
  const totalAmount = expenses.reduce((sum, expense) => sum + expense.amount, 0);
  const totalExpenses = expenses.length;
  const averageExpense = totalExpenses > 0 ? totalAmount / totalExpenses : 0;

  const categoryTotals: Record<string, number> = {};
  const monthlyTotals: Record<string, number> = {};

  expenses.forEach(expense => {
    // Category totals
    categoryTotals[expense.category] = (categoryTotals[expense.category] || 0) + expense.amount;

    // Monthly totals
    const monthKey = new Date(expense.date).toLocaleString('default', { month: 'long', year: 'numeric' });
    monthlyTotals[monthKey] = (monthlyTotals[monthKey] || 0) + expense.amount;
  });

  return {
    totalAmount,
    totalExpenses,
    averageExpense,
    categoryTotals,
    monthlyTotals
  };
};

export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR'
  }).format(amount);
};

export const generateId = (): string => {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
};