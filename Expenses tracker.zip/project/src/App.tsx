import React, { useState } from 'react';
import { useExpenses } from './hooks/useExpenses';
import { calculateStats } from './utils/calculations';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import ExpenseCharts from './components/ExpenseCharts';
import ExpenseForm from './components/ExpenseForm';
import ExpenseList from './components/ExpenseList';

function App() {
  const { expenses, categories, loading, addExpense, deleteExpense } = useExpenses();
  const [showAddModal, setShowAddModal] = useState(false);
  
  const stats = calculateStats(expenses);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 flex items-center justify-center">
        <div className="text-center">
          <div className="relative">
            <div className="w-16 h-16 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin mx-auto mb-6"></div>
            <div className="absolute inset-0 w-16 h-16 border-4 border-transparent border-t-purple-400 rounded-full animate-spin mx-auto" style={{ animationDirection: 'reverse', animationDuration: '1.5s' }}></div>
          </div>
          <p className="text-gray-600 font-medium">Loading your expenses...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <Header onAddExpense={() => setShowAddModal(true)} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Dashboard stats={stats} />
        
        <div className="mb-8">
          <ExpenseCharts stats={stats} categories={categories} />
        </div>
        
        {expenses.length === 0 ? (
          <div className="text-center py-16">
            <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl border border-white/20 p-12 max-w-lg mx-auto">
              <div className="w-24 h-24 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
                <span className="text-4xl">💰</span>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-3">Start Your Financial Journey</h3>
              <p className="text-gray-600 mb-8 leading-relaxed">Track your expenses and gain insights into your spending patterns with beautiful charts and analytics.</p>
              <button
                onClick={() => setShowAddModal(true)}
                className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-8 py-4 rounded-2xl hover:from-blue-700 hover:to-purple-700 transition-all duration-300 transform hover:scale-105 shadow-lg font-semibold"
              >
                Add Your First Expense
              </button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <ExpenseList
                expenses={expenses}
                categories={categories}
                onDeleteExpense={deleteExpense}
              />
            </div>
            <div>
              <ExpenseForm
                categories={categories}
                onAddExpense={addExpense}
              />
            </div>
          </div>
        )}
      </main>
      
      {showAddModal && (
        <ExpenseForm
          categories={categories}
          onAddExpense={addExpense}
          onClose={() => setShowAddModal(false)}
          isModal={true}
        />
      )}
    </div>
  );
}

export default App;